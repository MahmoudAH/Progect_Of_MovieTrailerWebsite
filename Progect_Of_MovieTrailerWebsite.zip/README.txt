Movie Trailer Website Project

to run this website:
click on fresh_tomatoes.html
with IDLE:
use one of this built function
1-execfile such execfile('name of project')
2-popen
or open new window from "file",
write your code and from run press"run module" 
enjoy listining trailers of 6 movies
